package documentacion;


public class Principal {
/**
 * 
 * @param args. Coge los metodos de la clase Metodos y los ejecuta
 */
	public static void main(String[] args) {

		new Metodos();
		documentacion.Metodos.generadorNumerosAleatorios();

		new Metodos();
		documentacion.Metodos.textoAdivina();

		new Metodos();
		documentacion.Metodos.numeroIntroducido();

	}
}