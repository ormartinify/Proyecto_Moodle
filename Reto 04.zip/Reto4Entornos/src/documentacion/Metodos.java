package documentacion;
import java.util.Scanner;
/**
 * 
 * @author Oscar
 *
 */
public class Metodos {
	static int numeroGenerado;
/**
 * @param Nos genera un numero aleatorio del 0 al 100 y lo guarda en la variable numeroGenerado
 */
	public static void generadorNumerosAleatorios() {
		numeroGenerado = (int) Math.floor(Math.random() * 101);

	}
/**
 * @param Solamente mostrará el texto indicado abajo
 */
	public static void textoAdivina() {
		System.out.println("Vamos a adivinar un número del 0 al 100");

	}
/**
 * @param Nos pedirá que introduzcamos un número por teclado y si el numero es correcto mostrara un mensaje felicitandonos. En caso contrario nos dira que volvamos a intentarlo
 */
	public static void numeroIntroducido() {
		System.out.println("Introduce el número que has pensado y pulsa enter:");
		Scanner teclado = new Scanner(System.in);
		int numeroPensado = teclado.nextInt();
		if (numeroPensado == numeroGenerado) {
			System.out.println("¡¡Felicidades, has adivinado el número!!");
		} else {
			System.out.println("Vuelve a intentarlo. El número era el " + numeroGenerado + ".");
		}

	}

}