/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package documentacion;

import java.util.Scanner;

/**
 *
 * @author damiansu
 */
public class Original {

    /**
     * @param args the command line arguments
     */
    private static int funcion(int b){
        return (int) (Math.random()*200-1);
    }
    
    public static void eowie(){
        System.out.println("Adivina el nÃºmero del 1 al ... ");
    }
    public static void main(String[] args) {
        
        eowie();
        
        Scanner toucka = new Scanner(System.in);
        int c = -900;
        
        c=funcion(c);
        
        System.out.println(c);
        
        
        
    }
    
}

/*
 * Se dispone del siguiente código de CajaBlanca.java de la tarea anterior. Se pide:

Realiza la documentación más precisa posible del código. Para ello, investiga sobre lo que és el javadoc.

Viendo el nombre de las variables, métodos o los identificadores que se están utilizando en el programa, realiza una refactorización siguiendo
los patrones de Renombrado y Sustitución bloques de código por método (Patrones de refactorización más habituales). Ayúdate de las herramientas que ofrece el IDE.

Debido al cambio que has hecho en el código, utiliza la herramienta de control de versiones del IDE para notiificar los cambios que has realizado.*/
